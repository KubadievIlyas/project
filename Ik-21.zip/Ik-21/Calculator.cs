﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kubadiev
{  
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double rost = Convert.ToInt32(textBox1.Text);
            double rost_metr = rost / 100;
            double ves = Convert.ToInt32(textBox2.Text);
            double index = Math.Round((ves / (rost_metr * rost_metr)), 1);
            label8.Text = index.ToString();

            if (index < 10)
            { trackBar1.Value = 10; label16.Text = "Недостаточный вес"; }


            else if (index >= 10 && index < 18.5)
            { trackBar1.Value = Convert.ToInt32(index); label16.Text = "Недостаточный вес"; }

            else if (index >= 18.5 && index < 24.9)
            { trackBar1.Value = Convert.ToInt32(index); label16.Text = "Здоровый вес"; }

            else if (index >= 24.9 && index <= 30)
            { trackBar1.Value = Convert.ToInt32(index); label16.Text = "Избыточный вес"; }

            else if (index > 30)
            { trackBar1.Value = Convert.ToInt32(index); label16.Text = "Ожирение";}
            
            
            
            
            label8.Text = index.ToString();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Load(Man.png);
        }
    }
}
