﻿namespace map_kubadiev
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.Drinks = new System.Windows.Forms.PictureBox();
            this.firastaid = new System.Windows.Forms.PictureBox();
            this.Iinformation = new System.Windows.Forms.PictureBox();
            this.WC = new System.Windows.Forms.PictureBox();
            this.Energy = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.clear = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Drinks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.firastaid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Iinformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Energy)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.BackgroundImage = global::map_kubadiev.Properties.Resources._1;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(343, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(59, 59);
            this.button1.TabIndex = 1;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::map_kubadiev.Properties.Resources._2;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Location = new System.Drawing.Point(447, 173);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(56, 55);
            this.button2.TabIndex = 2;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::map_kubadiev.Properties.Resources._3;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Location = new System.Drawing.Point(403, 341);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(58, 59);
            this.button3.TabIndex = 3;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::map_kubadiev.Properties.Resources._4;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Location = new System.Drawing.Point(574, 415);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(56, 55);
            this.button4.TabIndex = 4;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::map_kubadiev.Properties.Resources._5;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Location = new System.Drawing.Point(347, 580);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(55, 54);
            this.button5.TabIndex = 5;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackgroundImage = global::map_kubadiev.Properties.Resources._6;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.Location = new System.Drawing.Point(171, 532);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(55, 56);
            this.button6.TabIndex = 6;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackgroundImage = global::map_kubadiev.Properties.Resources._7;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.Location = new System.Drawing.Point(54, 389);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(56, 55);
            this.button7.TabIndex = 7;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackgroundImage = global::map_kubadiev.Properties.Resources._8;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button8.Location = new System.Drawing.Point(21, 126);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(56, 55);
            this.button8.TabIndex = 8;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::map_kubadiev.Properties.Resources.map;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(639, 622);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button9
            // 
            this.button9.BackgroundImage = global::map_kubadiev.Properties.Resources.finish;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button9.Location = new System.Drawing.Point(161, 21);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(34, 95);
            this.button9.TabIndex = 10;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackgroundImage = global::map_kubadiev.Properties.Resources.map_icon_start;
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button10.Location = new System.Drawing.Point(408, 569);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(64, 65);
            this.button10.TabIndex = 11;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button12
            // 
            this.button12.BackgroundImage = global::map_kubadiev.Properties.Resources.map_icon_start;
            this.button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button12.Location = new System.Drawing.Point(201, 36);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(64, 65);
            this.button12.TabIndex = 13;
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.BackgroundImage = global::map_kubadiev.Properties.Resources.map_icon_start;
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button13.Location = new System.Drawing.Point(46, 249);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(64, 65);
            this.button13.TabIndex = 14;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // Drinks
            // 
            this.Drinks.BackgroundImage = global::map_kubadiev.Properties.Resources.map_icon_drinks;
            this.Drinks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Drinks.Location = new System.Drawing.Point(670, 149);
            this.Drinks.Name = "Drinks";
            this.Drinks.Size = new System.Drawing.Size(88, 79);
            this.Drinks.TabIndex = 20;
            this.Drinks.TabStop = false;
            this.Drinks.Visible = false;
            // 
            // firastaid
            // 
            this.firastaid.BackgroundImage = global::map_kubadiev.Properties.Resources.map_icon_medical;
            this.firastaid.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.firastaid.Location = new System.Drawing.Point(670, 556);
            this.firastaid.Name = "firastaid";
            this.firastaid.Size = new System.Drawing.Size(88, 78);
            this.firastaid.TabIndex = 21;
            this.firastaid.TabStop = false;
            this.firastaid.Visible = false;
            // 
            // Iinformation
            // 
            this.Iinformation.BackgroundImage = global::map_kubadiev.Properties.Resources.map_icon_information;
            this.Iinformation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Iinformation.Location = new System.Drawing.Point(670, 456);
            this.Iinformation.Name = "Iinformation";
            this.Iinformation.Size = new System.Drawing.Size(88, 79);
            this.Iinformation.TabIndex = 22;
            this.Iinformation.TabStop = false;
            this.Iinformation.Visible = false;
            // 
            // WC
            // 
            this.WC.BackgroundImage = global::map_kubadiev.Properties.Resources.map_icon_toilets;
            this.WC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.WC.Location = new System.Drawing.Point(670, 350);
            this.WC.Name = "WC";
            this.WC.Size = new System.Drawing.Size(88, 82);
            this.WC.TabIndex = 23;
            this.WC.TabStop = false;
            this.WC.Visible = false;
            // 
            // Energy
            // 
            this.Energy.BackgroundImage = global::map_kubadiev.Properties.Resources.map_icon_energy_bars1;
            this.Energy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Energy.Location = new System.Drawing.Point(670, 249);
            this.Energy.Name = "Energy";
            this.Energy.Size = new System.Drawing.Size(88, 79);
            this.Energy.TabIndex = 24;
            this.Energy.TabStop = false;
            this.Energy.Visible = false;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(758, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 37);
            this.label3.TabIndex = 27;
            this.label3.Text = "Drinks";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Visible = false;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(758, 274);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 30);
            this.label4.TabIndex = 28;
            this.label4.Text = "Energy bars";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Visible = false;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(758, 380);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(159, 30);
            this.label5.TabIndex = 29;
            this.label5.Text = "WC";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Visible = false;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(764, 482);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(159, 30);
            this.label6.TabIndex = 30;
            this.label6.Text = "Information";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Visible = false;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(764, 580);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(173, 30);
            this.label7.TabIndex = 31;
            this.label7.Text = "First-aid post";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Visible = false;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(670, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(247, 37);
            this.label2.TabIndex = 33;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Visible = false;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(670, 89);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(247, 37);
            this.label9.TabIndex = 34;
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(657, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(280, 638);
            this.panel1.TabIndex = 35;
            // 
            // clear
            // 
            this.clear.BackgroundImage = global::map_kubadiev.Properties.Resources._78_789091_red_cross_mark_clipart_big_red_x_clipart;
            this.clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.clear.Location = new System.Drawing.Point(612, 12);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(39, 26);
            this.clear.TabIndex = 36;
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(12, 15);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(42, 23);
            this.button11.TabIndex = 37;
            this.button11.Text = "EXIT";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(929, 646);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Energy);
            this.Controls.Add(this.WC);
            this.Controls.Add(this.Iinformation);
            this.Controls.Add(this.firastaid);
            this.Controls.Add(this.Drinks);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Drinks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.firastaid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Iinformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Energy)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private PictureBox pictureBox1;
        private Button button9;
        private Button button10;
        private Button button12;
        private Button button13;
        private PictureBox Drinks;
        private PictureBox firastaid;
        private PictureBox Iinformation;
        private PictureBox WC;
        private PictureBox Energy;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label2;
        private Label label9;
        private Panel panel1;
        private Button clear;
        private Button button11;
    }
}