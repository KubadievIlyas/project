using Microsoft.VisualBasic;

namespace map_kubadiev
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            x();
            Drinks.Visible = true; label3.Visible = true;
            WC.Visible = true; label5.Visible = true;
            firastaid.Visible = true; label7.Visible = true;
            label9.Text = "Julebino"; label9.Visible = true;
            label2.Text = "Short distance"; label2.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            x();
            Energy.Visible = true; label4.Visible = true;
            WC.Visible = true; label5.Visible = true;
            Iinformation.Visible = true; label6.Visible = true;
            label9.Text = "Kosino"; label9.Visible = true;
            label2.Text = "Short distance"; label2.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            x();
            WC.Visible = true; label5.Visible = true;
            Iinformation.Visible = true; label6.Visible = true;
            label9.Text = "Nekrasovka"; label9.Visible = true;
            label2.Text = "Short distance"; label2.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            x();
            firastaid.Visible = true; label7.Visible = true;
            Energy.Visible = true; label4.Visible = true;
            label9.Text = "Vyhino"; label9.Visible = true;
            label2.Visible = true; label2.Text = "Short distance"; 
        }

        private void button5_Click(object sender, EventArgs e)
        {
            x();
            Drinks.Visible = true; label3.Visible = true;
            Energy.Visible = true; label4.Visible = true;
            WC.Visible = true; label5.Visible = true;
            Iinformation.Visible = true; label6.Visible = true;
            firastaid.Visible = true; label7.Visible = true;
            label9.Text = "Kotelniki"; label9.Visible = true;
            label2.Text = "Average distance"; label2.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            x();
            firastaid.Visible = true; label7.Visible = true;
            Iinformation.Visible = true; label6.Visible = true;
            WC.Visible = true; label5.Visible = true;
            label9.Text = "Okskaya"; label9.Visible = true;
            label2.Text = "Average distance"; label2.Visible = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            x();
            Energy.Visible = true; label4.Visible = true;
            WC.Visible = true; label5.Visible = true;
            label9.Text = "Lublino"; label9.Visible = true;
            label2.Text = "Average distance"; label2.Visible = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            x();
            
            Iinformation.Visible = true; label6.Visible = true;
            Energy.Visible = true; label4.Visible = true;
            label9.Text = "Luhmanovskay"; label9.Visible = true;
            label2.Text = "Long distance"; label2.Visible = true;
        }

        void x ()
        {
            Energy.Visible = false; label4.Visible = false;
            WC.Visible = false; label5.Visible = false;
            Iinformation.Visible = false; label6.Visible = false;
            firastaid.Visible = false; label7.Visible = false;
            Drinks.Visible = false; label3.Visible = false;
            label2.Visible = false; label9.Visible = false;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            x();
            label9.Visible = true;
            label2.Visible = true;
            label2.Text = "Start!";
            label9.Text = "Average distance";
        }

        private void button13_Click(object sender, EventArgs e)
        {
            x();
            label9.Visible = true;
            label2.Visible = true;
            label2.Text = "Start!";
            label9.Text = "Long distance";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            x();
            label9.Visible = true;
            label2.Visible = true;
            label2.Text = "Start!";
            
            label9.Text = "Short distance";

        }

        private void button9_Click(object sender, EventArgs e)
        {
            x();
            label9.Visible = true; label2.Visible = true;
            label2.Text = "Finish";
            
            label9.Text = "Congratulations!";
        }

        private void clear_Click(object sender, EventArgs e)
        {
            x();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}